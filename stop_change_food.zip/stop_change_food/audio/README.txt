The audio files were created from:
audiocheck.net_sin_1000Hz_-3dBFS_.1s.wav

They are 1000hz, at -3dBFS, 100ms, and sampled at the rate of 44.1
